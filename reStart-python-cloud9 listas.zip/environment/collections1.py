
myFavoriteFruitDictionary = {
      "Akua" : "apple",
      "Saanvi" : "banana",
      "Paulo" : "pineapple"
    }
print (myFavoriteFruitDictionary["Akua"])
print (type(myFavoriteFruitDictionary))