"""
concatenate

"""
firststring = "this is the first"
secondstring = "this is the second"
total = firststring + secondstring
print (total)

