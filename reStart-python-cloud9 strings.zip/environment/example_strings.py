mystring= "this is a string"
print (mystring)
print (type(mystring))
print (mystring + "is of the data type" + str(type(mystring)))