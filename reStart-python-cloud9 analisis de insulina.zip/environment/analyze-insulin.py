import recontenido=open("preproinsulin-seq.txt")
       cadena=contenido.read()
       clean = re.sub(r'\s+|/|ORIGIN|1|61', '', cadena)
       print(clean)
       print(len(clean))
#In lsinsulin-seq-clean.txt, 
save amino acids 1–24. 
Verify that your file has 24 
characters.p1=clean[0:24]
#In binsulin-seq-clean.txt, 
save amino acids 25–54. 
Verify that your file has 30 characters.
p2=clean[24:54]
#In cinsulin-seq-clean.txt, 
save amino acids 55–89. 
Verify that your file has 35 characters.
p3=clean[54:89]
#In ainsulin-seq-clean.txt, save amino acids 90–110. 
Verify that your file has 21 characters.
p4=clean[89:110]
print(p1)
print(len(p1))
print(p2)
print(len(p2))
print(p3)
print(len(p3))
print(p4)
print(len(p4))