milista = ["manzana","pera","cereza"]
print(milista)
print(type(milista))

print(milista[2])

milista[2] = "gato"

print(milista)